Copy Protocol/headtracker.xml to fgdata/Protocol/headtracker.xml

$ fgfs --generic=socket,in,25,localhost,5542,udp,headtracker

Adjust paths as necessary.

cheers,
-sh 20131008
