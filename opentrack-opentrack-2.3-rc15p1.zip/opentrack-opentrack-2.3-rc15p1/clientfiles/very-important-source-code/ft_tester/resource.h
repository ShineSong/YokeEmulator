#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define IDQUIT                                  1002
#define IDC_YAW                                 1005
#define IDC_PITCH                               1023
#define IDC_ROLL                                1024
#define IDC_X                                   1025
#define IDC_Y                                   1026
#define IDC_Z                                   1027
#define IDC_RYAW                                1028
#define IDC_RPITCH                              1029
#define IDC_RROLL                               1030
#define IDC_RX                                  1031
#define IDC_RY                                  1032
#define IDC_RZ                                  1033
#define IDC_NUM                                 1034
#define IDC_RES                                 1035
#define IDC_PT0                                 1036
#define IDC_PT1                                 1037
#define IDC_PT2                                 1038
#define IDC_PT3                                 1039
#define IDC_START                               1040
#define IDC_TITLE                               1041

