#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define IDQUIT                                  1002
#define IDSTART                                 1003
#define IDC_APPID                               1016
#define IDC_PITCH                               1017
#define IDC_YAW                                 1018
#define IDC_ROLL                                1019
#define IDC_X1                                  1020
#define IDC_X2                                  1021
#define IDC_X3                                  1022
#define IDC_Y1                                  1023
#define IDC_Y2                                  1024
#define IDC_Y3                                  1025
#define IDC_Z1                                  1026
#define IDC_Z2                                  1027
#define IDC_Z3                                  1028
#define IDC_S                                   1029
#define IDC_F                                   1030

