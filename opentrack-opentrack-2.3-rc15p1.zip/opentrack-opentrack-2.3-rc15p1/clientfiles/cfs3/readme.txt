FaceTrackNoIR for 

    * Combat Flight Simulator 3 (also works for Over Flanders Fields)
    * Wings of War
    * NASCAR Racing Season 2003
    * Colin McRae Rally 4
    * Race Driver 2
    * F1 Challenge
    * Richard Burns Rally

FaceTrackNoIR was made compatible with these programs with the help of the functions TrackIR provides in the dll TIRViews.dll.
This dll can be downloaded from the TrackIR website: http://www.naturalpoint.com/trackir/06-support/support-download-software-and-manuals.html

To make the functions work, copy the dll in the FaceTrackNoIR installation folder. Then tick the 'use TIRViews.dll' checkbox for the 'fake TrackIR' game protocol.

Please let us know if you like the program, if you have ideas for improvements or any questions you might have.



The FaceTrackNoIR team:

Wim Vriend
Ron Hendriks



Disclaimer: For usage of 3rd party software like FlightGear, the FaceTrackNoIR team is not responsible. Use it at your own risk.