FaceTrackNoIR for PPJoy 'enabled' games/programs.

FaceTrackNoIR was made compatible with the PPJoy virtual joystick(s), that can be used by various other programs as input.

To start the PPJoy protocol-server in FaceTrackNoIR, select Virtual Joystick in the 'game-protocol' listbox. The 
settings, necessary to configure PPJoy for FaceTrackNoIR as included in the PPJoy folder, in the file 
PPJoy mapping for FaceTrackNoIR.jpg.

PPJoy was made by Deon van der Westhuysen and is unfortunately not updated anymore. You can download it from the website
http://shareware.pcmag.com/free/Miscellaneous-Utilities/PPJoy/75176.html, but possibly from others as well...


Regards,


The FaceTrackNoIR team:

Wim Vriend
Ron Hendriks




Disclaimer: For usage of 3rd party software like PPJoy, the FaceTrackNoIR team is not responsible. Use it at your own risk.