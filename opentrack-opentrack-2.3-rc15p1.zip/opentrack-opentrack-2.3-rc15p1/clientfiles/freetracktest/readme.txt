FaceTrackNoIR for Free-track 'enabled' games.

FaceTrackNoIR was made compatible with the Free-track protocol, for which the Free-track source (a well, part of it) was
translated from Delphi Pascal to C++ (Visual Studio C++, with Qt).

To start the Free-track protocol-server in FaceTrackNoIR, select Free-track in the 'game-protocol' listbox. The program
'FreeTrackTest.exe' is provided to check, if the protocol-server is running.

FreeTrackTest.exe was created by the Free-track team.



The FaceTrackNoIR team:

Wim Vriend
Ron Hendriks



Disclaimer: For usage of 3rd party software like FreeTrackTest, the FaceTrackNoIR team is not responsible. Use it at your own risk.